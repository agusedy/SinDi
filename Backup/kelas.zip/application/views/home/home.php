<aside class="right-side">

    <!-- Main content -->
    <section class="content">
    <p align="center">
    	<img src="<?php echo base_url('assets/logo_SD.jpg');?>">
    </p>
    </section><!-- /.content -->
</aside><!-- /.right-side -->
<style type="text/css" media="screen">
    img {
position: relative;
left: -100px;
}
</style>