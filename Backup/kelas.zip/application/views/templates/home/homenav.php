<!-- header logo: style can be found in header.less -->
<header class="header">
    <a href="../../index.html" class="logo">
        <!-- Add the class icon to your logo image or logo icon to add the margining -->
        Raport
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" role="navigation">
        <ul class="nav navbar-nav">
	    	<li>
	        	<a href="<?php echo site_url('home');?>">Home</a>
	        </li>
	        <li>
	        	<a href="<?php echo site_url('home/login');?>">Login</a>
	        </li>
	    </ul>
    </nav>
</header>